package org.wzz.domain;

import lombok.Data;

@Data
public class BookCategory {
    private Integer categoryId;

    private String categoryName;
}